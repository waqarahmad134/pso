<?php $__env->startSection('content'); ?>

    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                 <div class="col-md-6 col-sm-12">
                     <h2>Add Daily Record</h2>
                 </div>
             </div> 
         </div>
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                                <h2>General Information</h2>
                        </div>
                        <form method="POST" action="<?php echo e(route('add_admins')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="body">
                                <div class="row">
                                    <div class="col-md-6 col-lg-4">
                                        <label>Date</label>
                                        <input name="date" type="date" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 col-lg-4">
                                        <label>Shift</label>
                                        <select name="shift" class="form-control" required>
                                            <option value="">-- Select Shift --</option>
                                            <option value="Day">Day</option>
                                            <option value="Night">Night</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-lg-4">
                                        <label>Cashier</label>
                                        <select name="cashier_id" class="form-control" required>
                                            <option value="">-- Select Cashier (Customer) --</option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> (<?php echo e($customer->email); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6 col-lg-6">
                                        <label>DIP Petrol</label>
                                        <select name="shift" class="form-control" required>
                                            <option value="">-- Select --</option>
                                            <option value="100">100</option>
                                            <option value="200">200</option>
                                            <option value="300">300</option>
                                            <option value="400">400</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-lg-6">
                                        <label>DIP Diesel</label>
                                        <select name="shift" class="form-control" required>
                                            <option value="">-- Select --</option>
                                            <option value="100">100</option>
                                            <option value="200">200</option>
                                            <option value="300">300</option>
                                            <option value="400">400</option>
                                        </select>
                                    </div>
                                  
                                </div>
                                <div class="header p-0 mt-4">
                                    <h2>Sales Information</h2>
                                </div>

                                <input type="submit" class="btn mt-3 mb-3 float-right" style="background-color: #002E63; color: white;" value="Add Record" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPso\resources\views/admin/record.blade.php ENDPATH**/ ?>