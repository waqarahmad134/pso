<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'User Management | Express Ease'); ?>
<div id="main-content">
    <div class="block-header">
    </div>
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>User Management</h2>
                        <ul class="header-dropdown dropdown dropdown-animated scale-left">
                            <li> <a href="javascript:void(0);" data-toggle="cardloading" data-loading-effect="pulse"><i class="icon-refresh"></i></a></li>
                            <li><a href="javascript:void(0);" class="full-screen"><i class="icon-size-fullscreen"></i></a></li>
                        </ul>
                    </div>
                    <div class="body">
                        <div class="table-responsive">
                            <!--<table class="table table-bordered table-hover js-basic-example dataTable table-custom">-->
                            <table id="example1" class="table table-bordered table-hover js-basic-example dataTable table-custom">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Created At</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                        <th>Bookings</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($count++); ?></td>
                                        <td><?php echo e($d->name); ?></td>
                                        <td><?php echo e($d->contact); ?></td>
                                        <td><?php echo e($d->email); ?></td>
                                        <td><?php echo e(date('d,M Y h:i:s',strtotime($d->created_at))); ?></td>
                                        <td>
                                            <?php if($d->status==1): ?>
                                            <span>Active</span>
                                            <?php else: ?>
                                            <span>Block</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($d->status==1): ?>
                                            <a href="<?php echo e(route('block_admin',['id'=>$d->id])); ?>" class="btn" style="background-color: #c70032; color: white;">Block</a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('active_admin',['id'=>$d->id])); ?>" class="btn" style="background-color: #002E63; color: white;">Active</a>
                                            <?php endif; ?>
                                        </td>
                                        <td><a href="<?php echo e(route('booking_data',['id'=>$d->id])); ?>" class="btn btn-info">View</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#example1').DataTable({
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'copy',
                    exportOptions: {
                        columns: ':not(:nth-child(8)):not(:nth-child(9))'
                    }
                },
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(:nth-child(8)):not(:nth-child(9))'
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(:nth-child(8)):not(:nth-child(9))'
                    }
                }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPso\resources\views/admin/list_users.blade.php ENDPATH**/ ?>