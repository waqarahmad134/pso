<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'User Management | Express Ease'); ?>

<?php $__env->startSection('content'); ?>
<div id="main-content">
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>User Management</h2>
                    </div>
                    <div class="body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-hover js-basic-example dataTable table-custom">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Created At</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count = 1; ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($count++); ?></td>
                                        <td><?php echo e($d->name); ?></td>
                                        <td><?php echo e($d->contact); ?></td>
                                        <td><?php echo e($d->email); ?></td>
                                        <td><?php echo e(date('d,M Y h:i:s', strtotime($d->created_at))); ?></td>
                                        <td>
                                            <?php if($d->status == "active"): ?>
                                                <span>Active</span>
                                            <?php else: ?>
                                                <span>Block</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($d->status == "active"): ?>
                                                <a href="<?php echo e(route('update_status', ['id' => $d->id])); ?>" class="btn btn-danger">Block</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('update_status', ['id' => $d->id])); ?>" class="btn btn-success">Active</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPso\resources\views/admin/staffs.blade.php ENDPATH**/ ?>